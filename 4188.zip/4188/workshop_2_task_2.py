stream = modeler.script.stream()

row_fields = [u'GENDER',u'REGION',u'AGE_CATEGORY',u'SEGMENT',u'HANDSET']

matrix_node = stream.findByType("matrix", None)

for row_field in row_fields:
    matrix_node.setPropertyValue ("row", row_field)
    text = str (row_field) + u" BY CHURN"
    matrix_node.setPropertyValue("output_name",text)
  
    executionResults = []
    matrix_node.run (executionResults)
