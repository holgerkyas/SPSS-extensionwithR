stream = modeler.script.stream()
matrix_node = stream.findByType("matrix", None)
data_model = matrix_node.getInputDataModel ()

for row_field in data_model.columnIterator():
    for column_field in data_model.columnIterator():
        if row_field.isMeasureDiscrete() and column_field.isMeasureDiscrete():
            if str (row_field.getModelingRole()) == "Input" and str (column_field.getModelingRole()) == "Target":
                matrix_node.setPropertyValue("row",row_field)
                matrix_node.setPropertyValue("column",column_field)
                text = str (row_field) + " BY " + str (column_field)
                matrix_node.setPropertyValue("output_name",text)
                
                executionResults = []
                matrix_node.run(executionResults)
