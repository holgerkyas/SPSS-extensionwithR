stream = modeler.script.stream()
matrix_node = stream.findByType("matrix", None)
data_model  = matrix_node.getInputDataModel ()

for row_field in data_model.columnIterator():
        if row_field.isMeasureDiscrete() and str (row_field) != "CHURN":
            matrix_node.setPropertyValue("row", row_field)
            text  = str (row_field) + u" BY CHURN"
            matrix_node.setPropertyValue("output_name",text)
            
            executionResults = []
            matrix_node.run (executionResults)
